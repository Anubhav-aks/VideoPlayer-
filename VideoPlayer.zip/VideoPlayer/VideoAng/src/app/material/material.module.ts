import { NgModule } from '@angular/core';

import { MatToolbarModule} from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon'
import { MatGridListModule } from '@angular/material/grid-list';
import{MatListModule} from '@angular/material/list';
import{MatButtonModule} from '@angular/material/button';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';

const Materialtools=[MatToolbarModule,MatIconModule,MatGridListModule,
  MatListModule,MatButtonModule,MatFormFieldModule,MatInputModule]

@NgModule({
  
  imports: [Materialtools
  
  ],
  exports:[Materialtools]
})
export class MaterialModule { }
