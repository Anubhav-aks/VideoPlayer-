import { Component, OnInit } from '@angular/core';
import { Video } from '../video';

@Component({
  selector: 'video-details',
  templateUrl: './video-details.component.html',
  styleUrls: ['./video-details.component.css'],
  inputs:['video']
})
export class VideoDetailsComponent implements OnInit {
 public edit=false;
  constructor() { }
public video:Video;
  ngOnInit(): void {
  }
onTitle(){
  this.edit=true;
}
}
