import { Component, OnInit,EventEmitter } from '@angular/core';
import { Video } from '../video';

@Component({
  selector: 'video-list',
  templateUrl: './video-list.component.html',
  styleUrls: ['./video-list.component.css'],
  inputs: ['videos'],
  outputs: ['SelectedVideo']
})
export class VideoListComponent implements OnInit {

  constructor() { }
  videos;

  ngOnInit() { }
  public SelectedVideo=new  EventEmitter;

  onClick(video:Video){
this.SelectedVideo.emit(video);
  }
}
