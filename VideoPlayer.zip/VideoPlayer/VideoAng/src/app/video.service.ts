import { Injectable } from '@angular/core';

import {HttpClient} from '@angular/common/http'
import { Video } from './video';

@Injectable({
  providedIn: 'root'
})
export class VideoService {
readonly baseUrl='http://localhost:3000/videos';
  constructor(private http:HttpClient) { }

getVideo(){
  return this.http.get(this.baseUrl)
}
postVideo(vid:Video){
  return this.http.post(this.baseUrl,vid)
}
putVideo(vid:Video){
  return this.http.put(this.baseUrl+`${vid._id}`,vid)
}
deleteVideo(vid:Video){
  return this.http.delete(this.baseUrl+`${vid._id}`)
}
}
