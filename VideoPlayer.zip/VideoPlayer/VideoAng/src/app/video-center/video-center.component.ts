import { Component, OnInit } from '@angular/core';

import {Video} from '../video'
import { VideoService } from '../video.service';

@Component({
  selector: 'app-video-center',
  templateUrl: './video-center.component.html',
  styleUrls: ['./video-center.component.css'],
  providers:[VideoService]
})
export class VideoCenterComponent implements OnInit {
videos:any;
  constructor(private videoService:VideoService) { }
public selectedVideo:Video;
  ngOnInit(){
    this.videoService.getVideo().subscribe(data=>this.videos=data)
  }
  onSelect(vid:any){
    this.selectedVideo=vid;
    console.log(this.selectedVideo)
  }
}
