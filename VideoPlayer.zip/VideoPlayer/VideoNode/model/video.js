const mongoose=require('mongoose');
var Video=mongoose.model('Video',{
    title:{type:String},
    url:{type:String},
    description:{type:String}
})
module.exports={Video};