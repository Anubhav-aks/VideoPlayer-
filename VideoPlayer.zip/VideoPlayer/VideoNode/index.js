var express=require('express');
var bodyParser=require('body-parser');
var cors=require('cors');

var app=express();
var {mongoose} =require('./db.js');
var router=require('./controller/controller.js')
app.use(cors({origin:'http://localhost:4200'}));
app.use(bodyParser.json());
app.listen(3000, console.log("Server is running at 'http://localhost:3000'"));
app.use('/videos',router);