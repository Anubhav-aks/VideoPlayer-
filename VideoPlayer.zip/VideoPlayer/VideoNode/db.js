var mongoose = require('mongoose');

var url = 'mongodb://localhost:27017/VideoDB';

mongoose.connect(url, function (err) {
    if (err) throw err;
    console.log("MongoDb is Connected");
    
})
module.exports = mongoose;