var mongoose = require('mongoose');
var express = require('express');
var router = express.Router();

var { Video } = require('../model/video.js');
var ObjectId=require('mongoose').Types.ObjectId;

router.get('/', function (req, res) {
    Video.find((err, doc) => {
        if (!err) {
            res.send(doc);
        }
        else {
            console.log("Error:" + JSON.stringify(err, undefined, 2))
        }
    })
})
router.get('/:id', function (req, res) {
    if(!ObjectId.isValid(req.params.id)){
        return res.status(400).send('No  record found!')
    }
    Video.findById((err, doc) => {
        if (!err) {
            res.send(doc);
        }
        else {
            console.log('Error:' + JSON.stringify(err, undefined, 2))
        }
    })
})

router.post('/',function(req,res){
    var vid=new Video({
        title:req.body.title,
        url:req.body.url,
        description:req.body.description
    })
    vid.save((err,doc)=>{
        if(!err){
            res.send(doc)
        }
        else{
            console.log("Error in Posting:"+JSON.stringify(err,undefined,2))
        }
    })
})
router.put('/:id',function(req,res){
    if(!ObjectId.isValid(req.params.id))
    return res.status(400).send('No Record found')

    var vid={
        title:req.body.title,
        url:req.body.url,
        description:req.body.description
    }
  Video.findByIdAndUpdate(url.params.id,{$set:vid},{new:true},function(err,doc){
      if(!err){
          res.send(doc);
      }
      else{
          console.log('Erroris update:'+JSON.stringify(err,undefined,2))
      }
  })
 router.delete('/:id',function(req,res){
     if(ObjectId.isValid(req.params.id))
     return res.status(400).send('No record found')

     Video.findOneAndRemove(req.params.id,function(err,doc){
         if(!err){
             res.send(doc);
         }
         else{
             console.log('Error'+JSON.stringify(err,undefined,2))
         }
     })
 })
})

module.exports = router;